# ATS Resume Generator — Installation Guide

Thank you for purchasing **ATS Resume Generator**, a skill for Claude AI that tailors your resume to any job description in minutes.

---

## Option A — Claude Desktop (Cowork mode) ✅ Recommended

1. Download the `ats-resume.skill` file
2. Double-click it — Claude Desktop installs it automatically
3. Open a new conversation in Cowork
4. Type `/ats-resume`
5. Attach your current CV (PDF or DOCX) and paste the Job Description
6. Follow the prompts — Claude will ask a few questions to enrich your content, then generate your optimized `.docx`

---

## Option B — Claude Code (CLI)

1. Download the `ats-resume.skill` file and unzip it — you'll get a folder called `ats-resume` containing `SKILL.md`
2. Copy that folder to your Claude Code skills directory:

   **Mac / Linux:**
   ```bash
   mkdir -p ~/.claude/skills
   cp -r ats-resume ~/.claude/skills/
   ```

   **Windows:**
   ```
   C:\Users\[your-username]\.claude\skills\ats-resume\
   ```

3. Restart Claude Code
4. In any project, run `/ats-resume`
5. Attach your CV and paste the Job Description when prompted

---

## Requirements

- Claude Desktop (Cowork mode) **or** Claude Code CLI
- An active Claude subscription (Pro or higher recommended)

---

## What it does

- Analyzes your CV against the Job Description
- Asks targeted questions to extract metrics and achievements
- Rewrites every bullet with strong action verbs and quantified results
- Injects ATS keywords from the JD
- Fixes common rejection flags (length, language, generic summary, oversized skills section)
- Delivers a clean 1-page `.docx` following Harvard Career Services format
- Available in English, Spanish, or both

**Tested at 90%+ on real ATS checkers.**

---

## Support

Questions or feedback? Reach out at cajs0718@gmail.com
